Sinch RTC

The user guide can be found in the docs/user-guide directory.

The javadoc is located in docs/reference.

The REST API reference documentation can be found at docs/REST-API/user-guide/index.html.
